This folder contains files

RTM.EXE
BPC.EXE
STRINGS.TPU

which are part of the
Borland Pascal Version 7.0  Copyright (c) 1983,92 Borland International

These files are needed to compile the TPC16 compiler. Since Borland Pascal 7
is an old software and it is easy accessible over the internet I have decided
to include these files in the TPC16 package.